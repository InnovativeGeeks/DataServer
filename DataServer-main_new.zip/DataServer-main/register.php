<?php
/**
 * Created by PhpStorm.
 * User: 冰淇淋
 * Date: 2021/5/6
 * Time: 21:15
 * Use :
 */

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel = "stylesheet" type = "text/css" href = "../css/login.css">

    <title>Document</title>
</head>
<body>
<form class = "form-container" action="./php/to_register.php" method="POST">
    <p id = "error"></p>
    <h3>Register</h3>

    <div class = "form-grp">
        <label for ="username"> Username</label><br>
        <input type = "text" name = "username" placeholder = "given userid" id = "userid">
        <i class = "fa fa-times u_times"></i>
        <i class = "fa fa-check u_check"></i>
    </div>

    <div class = "form-grp">
        <label for = "=password">Password</label><br>
        <input type = "text" name = "password" placeholder = "password" id = "userpassword">
        <i class = "fa fa-times p_times"></i>
        <i class = "fa fa-check p_check"></i>
    </div>

    <div class = "form-grp">
        <input type = "submit" name = "login-button" value = "register">
    </div>

</form>
</body>
</html>
