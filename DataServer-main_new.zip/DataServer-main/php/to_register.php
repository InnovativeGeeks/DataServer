<?php
/**
 * Created by PhpStorm.
 * User: 冰淇淋
 * Date: 2021/5/6
 * Time: 21:18
 * Use :
 */
require "./mysql.php";
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$sql = "insert into user (username,password) values ('$username','$password')";
$res = mysqli_query($con,$sql);
if ($res){
    echo "<script>alert('注册成功');window.location.href = '../login.php'</script>";
}
