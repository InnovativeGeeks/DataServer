<?php
/**
 * Created by PhpStorm.
 * User: 冰淇淋
 * Date: 2021/5/6
 * Time: 21:18
 * Use :
 */
require "./mysql.php";
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$sql = "select *from user where username = '$username' and password = '$password'";
$res = mysqli_query($con,$sql);
$data = mysqli_fetch_assoc($res);

if (empty($data)){
    echo "<script>alert('账号或密码错误');window.location.href = '../login.php'</script>";exit;
}
echo "<script>alert('登录成功');window.location.href = '../upload.php'</script>"; 