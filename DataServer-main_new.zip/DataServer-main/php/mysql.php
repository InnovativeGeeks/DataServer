<?php
/**
 * Created by PhpStorm.
 * User: 冰淇淋
 * Date: 2021/5/6
 * Time: 21:18
 * Use :
 */
$con = mysqli_connect('localhost','root','root','www.login');
if (!$con) exit('数据库连接失败');