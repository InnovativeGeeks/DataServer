<?php
    function newconn(){
        $servername = "mysql-server";
        $username = "it06";
        $password = "innovativegeeks";
        $db = "it06";

        /*$servername = "127.0.0.1";
        $username = "root";
        $password = "";
        $db = "demo";*/

        $conn = new mysqli($servername, $username, $password, $db);
        return $conn;
    }
