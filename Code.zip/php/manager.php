<?php
    echo "<h1>Hello Manager</h1>";
?>

<!DOCTYPE html>
<html>

<head>
    <title>Panels</title>
    <script type="text/javascript" src="../js/panels.js"></script>
    <link rel="stylesheet" href="../css/panels.css"/>
</head>

<body onload="loadPanels()">
<h1>Panels</h1>
<div id="panelContainer" class="panParent">
    <div id="panels" class="panChild"></div>
    <div id="panelInfo" class="panChild"></div>
</div>
<?php
    session_start();
    $data = $_SESSION['data'];

    require_once "./databaseConnect.php";

    $conn = newconn();

    //select query
    $sql = "SELECT * FROM users;";
    $result = mysqli_query($conn, $sql);

    if($data['role'] ==1){
        echo "<h1> I’m Manager {$data['username']}</h1>";

        echo "Manager：";
        foreach (mysqli_fetch_all($result,MYSQLI_ASSOC) as $key => $value){
            echo $value['username'],'、';
        }
    }
?>
</body>
</html>
