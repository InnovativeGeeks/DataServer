<?php
/**
 * Created by Ryan Draper
 * 33152216
 */

function newconn(){
    $servername = "47.106.123.202";
    $username = "test_fenqi_group";
    $password = "N4iEdenf4sAsafFN";
    $db = "test_fenqi_group";

    $conn = new mysqli($servername, $username, $password, $db);

    return $conn;
}

