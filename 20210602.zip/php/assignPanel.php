<?php
$data = json_decode(file_get_contents('php://input'),true);

if(!empty($data)){
    require_once "./databaseConnect.php";

    $conn = newconn();

    $name = $_COOKIE['username'];
    $pid = $data['pid'];

    //select query
    $sql = "INSERT INTO userpanels(panel_id,username) VALUES('{$pid}','{$name}');";

    $result = mysqli_query($conn, $sql);

    echo json_encode(['error'=>0,'msg'=>'ok']);
}
else{
    echo json_encode(['msg'=>'No Data','error'=>1]);
}