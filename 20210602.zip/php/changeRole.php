<?php

$data = json_decode(file_get_contents('php://input'),true);

if(!empty($data)){
    require_once "./databaseConnect.php";

    $conn = newconn();


    $name = $_COOKIE['username'];
    $role = $data['role'];

    //select query
    $sql = "UPDATE users SET role='$role' WHERE username='$name';";

    $result = mysqli_query($conn, $sql);

    echo json_encode(['error'=>0,'msg'=>'ok']);
}
else{
    echo json_encode(['msg'=>'No Data','error'=>1]);
}
?>