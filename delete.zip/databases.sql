/*
 Navicat MySQL Data Transfer

 Source Server         : test_fenqi_group
 Source Server Type    : MySQL
 Source Server Version : 50733
 Source Host           : 47.106.123.202:3306
 Source Schema         : test_fenqi_group

 Target Server Type    : MySQL
 Target Server Version : 50733
 File Encoding         : 65001

 Date: 19/05/2021 16:05:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for panel
-- ----------------------------
DROP TABLE IF EXISTS `panel`;
CREATE TABLE `panel`  (
  `panelname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `dataname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `datatype` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nominal_min` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `nominal_max` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `currentval` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`panelname`, `dataname`, `username`) USING BTREE,
  INDEX `panel_ibfk_1_idx`(`username`) USING BTREE,
  CONSTRAINT `panel_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of panel
-- ----------------------------
INSERT INTO `panel` VALUES ('panel 1', 'temp', 'james1234', 'float', '0.2', '40', '25');
INSERT INTO `panel` VALUES ('weather', 'temp', 'ryan', 'integer', '0', '30', '10');
INSERT INTO `panel` VALUES ('weather', 'wind speed', 'ryan', 'integer', '0', '100', '30');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `username` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `role` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`username`) USING BTREE,
  UNIQUE INDEX `username_UNIQUE`(`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('fenqi', 'fenqi123', 1);
INSERT INTO `users` VALUES ('james1234', 'james4321', 2);
INSERT INTO `users` VALUES ('ryan', '1234', 2);
INSERT INTO `users` VALUES ('shri2224', 'shri4422', 1);
INSERT INTO `users` VALUES ('Xingze31', '123123', 0);

SET FOREIGN_KEY_CHECKS = 1;
