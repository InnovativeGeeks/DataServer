<?php
    echo "<h1>Hello Elec</h1>";
?>
<!--
    Created by Ryan Draper
    33152216
-->
<!DOCTYPE html>
<html>

<head>
    <title>Panels</title>
    <script type="text/javascript" src="../js/panels.js"></script>
    <link rel="stylesheet" href="../css/panels.css"/>
</head>

<body onload="loadPanels()">
<h1>Panels</h1>
<div id="panelContainer" class="panParent">
    <div id="panels" class="panChild"></div>
    <div id="panelInfo" class="panChild"></div>
</div>
<?php
    if (!session_id()) session_start();
    $data = $_SESSION['data'];

    if ($data['role'] == 2){
        echo "<h1>I’m electric supervisor Jame {$data['username']}</h1>";
        echo "the panels I’ll be able to check are electrical 1  2 3";

    }
    elseif ($data['role'] ==3){
        echo "<h1>Im user{$data['username']}</h1>";
    }

    require 'user_list.php';
?>
<form id="panelForm" method="post" action="./createPanel.php">
    <!-- Store username and password in hidden input for post -->
    <input type="text" hidden="true" name="username" id="username" value="<?php echo $count['username'];?>"></input>
    <input type="text" hidden="true" name="password" id="password" value="<?php echo $count['password'];?>"></input>

    <input type="submit" id="createPanel" value="create panel" />
</form>

</body>

</html>
