<?php
    require_once "./databaseConnect.php";
    $conn = newconn();

    if (!session_id()) session_start();
    $count  =  $_SESSION['data'];

    //select query
    if($count['role'] == 1){
        $sql = "SELECT * FROM users;";
    } else if($count['role'] == 2){
        $sql = "SELECT * FROM users where role=2;";
    }else if($count['role'] == 3){
        $sql = "SELECT * FROM users where username='{$count['username']}';";
    }

    $result = mysqli_query($conn, $sql);

    $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

?>
<html>
    <body>
        <table border="1" width="500" style="margin-top:10px;">
            <tr>
                <th>ID</th>
                <th>UserName</th>
                <th>Password</th>
                <th>Option</th>
            </tr>
            <?php foreach ($data as $key=>$value) {?>

            <tr align="center">
                <td><?php echo $key+1;?></td>
                <td><?php echo $value['username'];?></td>
                <td><?php echo $value['password'];?></td>
                <td>
                    <a href="user_del.php?username=<?php echo $value['username'];?>">Delete</a> &nbsp;&nbsp;
                    <a href="edit_del.php?username=<?php echo $value['username'];?>">Edit</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </body>
</html>
