<?php
/**
 * Created by Ryan Draper
 * 33152216
 */

function checkUser($u, $p)
{
    require_once "./databaseConnect.php";

    $conn = newconn();

    //select query
    $sql = "SELECT * FROM users WHERE username='$u' AND password='$p'";
    $result = mysqli_query($conn, $sql);

    //count number of rows
    return mysqli_fetch_array($result);
}

//get json data
$js = file_get_contents('php://input');

//decode json
$data = json_decode($js, true);

//get username and password
$username = $data['username'];
$password = $data['password'];

$count = checkUser($username, $password);

if (!session_id()) session_start();
$_SESSION['data'] = $count;
if ($count) {

    if($count['role'] == 1){
        $url = '/php/manager.php';
    } else if($count['role'] == 2){
        $url = '/php/superviseorElec.php';
    }else if($count['role'] == 3){
        $url = '/php/superviseorMech.php';
    }

    echo json_encode(['code'=>0,'msg'=>'success','url'=>$url]);

} else {
    echo 'invalid';
}
