<label for="file">file name：</label>
<input type="file" name="file" id="file">