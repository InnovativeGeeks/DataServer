<?php
/**
 * Created by Ryan Draper
 * 33152216
 */

    function newconn(){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $db = "demo";

        $conn = new mysqli($servername, $username, $password, $db);
        return $conn;
    }
