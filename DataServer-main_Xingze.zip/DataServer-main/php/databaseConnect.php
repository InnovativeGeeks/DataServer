<?php
    $servername = "127.0.0.1";
    $username = "ryan";
    $password = "Angusdraper2";
    $db = "my_db";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $db);
?>