/*!
 * Start Bootstrap - SB Admin v6.0.3 (https://startbootstrap.com/template/sb-admin)
 * Copyright 2013-2021 Start Bootstrap
 * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
 */
(function($) {
    "use strict";

    // Add active state to sidbar nav links
    var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
    $("#layoutSidenav_nav .sb-sidenav a.nav-link").each(function() {
        if (this.href === path) {
            $(this).addClass("active");
        }
    });

    // Toggle the side navigation
    $("#sidebarToggle").on("click", function(e) {
        e.preventDefault();
        $("body").toggleClass("sb-sidenav-toggled");
    });

    /**
     * A function that executes as soon as the document is ready.
     * Gets the logged in users name and role,
     * Hides navigational element depending on authority,
     * 
     * @author: Ryan Draper
     */
    $(document).ready(function() {
        //get logged in user and role
        var username = getCookie("username");
        var role = getCookie("role");

        //navigation links
        var manager = document.getElementById("manager");
        var create = document.getElementById("create");
        var add = document.getElementById("add");
        var del = document.getElementById("delete");

        //if the username is empty
        if (username == "") {
            //replace url with unauthorised page
            window.location.replace("../html/401.html");

        } else if (role == 1) { //if the user is super_admin
            //unhide manage tab
            manager.removeAttribute("hidden");

            //unhide create tab
            create.removeAttribute("hidden");

            //unhide update tab
            var update = document.getElementById("update");
            update.removeAttribute("hidden");

            //unhide add tab
            add.removeAttribute("hidden");

            //unhide delete tab
            del.removeAttribute("hidden");

            //set the users name in the side nav
            $("#loggedinUser").html(username);
            $("#usernav").html("Hello " + username);

        } else if (role == 2) { //if the user is admin
            //unhide manager tab
            manager.removeAttribute("hidden");

            //unhide create tab
            create.removeAttribute("hidden");

            //unhide update
            update.removeAttribute("hidden");

            //unhide add tab
            add.removeAttribute("hidden");

            //unhide delete tab
            del.removeAttribute("hidden");

            //set the users name in the side nav
            $("#loggedinUser").html(username);
            $("#usernav").html("Hello " + username);

        } else { //if the user is just a normal user
            //set the users name in the side nav
            $("#loggedinUser").html(username);
            $("#usernav").html("Hello " + username);
        }
    });

    /**
     * On click listener for the logoutBtn element.
     * 
     * @author: Ryan Draper
     */
    $("#logoutBtn").on("click", function() {
        //remove username cookie
        document.cookie = "username= ; expires = Thu, 01 Jan 1970 00:00:00 GMT; path=/";

        //remove role cookie
        document.cookie = "role= ; expires = Thu, 01 Jan 1970 00:00:00 GMT; path=/";

        //replace window with login page
        window.location.replace("../login.html");
    });
})(jQuery);

/*
    function getCookie
    author: w3Schools.com
    url: https://www.w3schools.com/js/js_cookies.asp
*/
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

/**
 * Created by Ryan Draper
 * 33152216
 */

//check if a var is empty
function emptyInput(str) {
    if (str === '' || str === null) {
        return true;
    }

    return false;
}

//check if two vars match
function doesNotMatch(str, str1) {
    if (str !== str1) {
        return true;
    }

    return false;
}

//check if a password is valid length
function invalidPassword(str) {
    if (str.length < 6) {
        return true;
    }

    return false;
}

//displays a message in the errorMessage element and makes it visible
function display(element, message) {
    element.innerText = message;
    element.hidden = false;
}

//function for checking validation of form inputs
function validate() {
    var username = document.getElementById('inputUsername');
    var password = document.getElementById('inputPassword');
    var conpassword = document.getElementById('inputConfirmPassword');
    var messageField = document.getElementById('message');
    var form = document.getElementById('changeForm');

    if (emptyInput(username.value.trim())) { //check empty username
        //set username field red outline
        username.setAttribute('class', 'form-control py-4 is-invalid');
        password.setAttribute('class', 'form-control py-4');
        conpassword.setAttribute('class', 'form-control py-4');

        //focus username field
        username.focus();

        //set message
        messageField.innerHTML = "username required";
        messageField.hidden = false;

        return false;
    } else if (emptyInput(password.value.trim())) { //check empty password
        //set password field red outline
        username.setAttribute('class', 'form-control py-4');
        password.setAttribute('class', 'form-control py-4 is-invalid');
        conpassword.setAttribute('class', 'form-control py-4');

        //focus password field
        password.focus();

        //set message
        messageField.innerHTML = "password required";
        messageField.hidden = false;

        return false;
    } else if (emptyInput(conpassword.value.trim())) { //check empty password
        //set confirmpassword field red outline
        username.setAttribute('class', 'form-control py-4');
        password.setAttribute('class', 'form-control py-4');
        conpassword.setAttribute('class', 'form-control py-4 is-invalid');

        //focus confirmpassword field
        conpassword.focus();

        //set message
        messageField.innerHTML = "confirm password required";
        messageField.hidden = false;

        return false;
    } else if (doesNotMatch(password.value.trim(), conpassword.value.trim())) {
        //set password and confirmpassword field red outline
        username.setAttribute('class', 'form-control py-4');
        password.setAttribute('class', 'form-control py-4 is-invalid');
        conpassword.setAttribute('class', 'form-control py-4 is-invalid');

        //focus password and confirmpassword field
        password.focus();
        conpassword.focus();

        //set message
        messageField.innerHTML = "passwords do not match";
        messageField.hidden = false;

        return false;
    } else if (invalidPassword(password.value.trim())) {
        //set password field red outline
        username.setAttribute('class', 'form-control py-4');
        password.setAttribute('class', 'form-control py-4 is-invalid');
        conpassword.setAttribute('class', 'form-control py-4');

        //focus password field
        password.focus();

        //set message
        messageField.innerHTML = "passwords must be a minimum of 6 characters";
        messageField.hidden = false;

        return false;
    } else {
        //store username and password
        const data = {
            oldUsername: getCookie("username"),
            username: username.value.trim(),
            password: password.value.trim()
        };

        //send post json data to url
        fetch('../php/changeDetails.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            })
            .then(response => response.text())
            .then(data => {
                if (data === 'success') { //if fetch returns success
                    //set message outline green. Change message text
                    messageField.setAttribute('class', 'alert alert-success');
                    messageField.innerHTML = "Details Changed";
                    messageField.hidden = false;

                    //expire cookies
                    document.cookie = "username= ; expires = Thu, 01 Jan 1970 00:00:00 GMT; path=/";

                    //set cookies
                    document.cookie = "username=" + username.value.trim() + "; path=/";

                    //submit form
                    form.submit();
                } else if (data === 'usertaken') { //if fetch returns usertaken
                    //set username and field red outline
                    username.setAttribute('class', 'form-control py-4 is-invalid');
                    password.setAttribute('class', 'form-control py-4');
                    conpassword.setAttribute('class', 'form-control py-4');

                    //set message outline red. Change message text
                    messageField.setAttribute('class', 'alert alert-danger');
                    messageField.innerHTML = "username taken. Please choose a different username";
                    messageField.hidden = false;
                } else {
                    //set username and field red outline
                    username.setAttribute('class', 'form-control py-4 is-invalid');
                    password.setAttribute('class', 'form-control py-4 is-invalid');
                    conpassword.setAttribute('class', 'form-control py-4 is-invalid');

                    //set message outline red. Change message text
                    messageField.setAttribute('class', 'alert alert-danger');
                    messageField.innerHTML = "An error occured";
                    messageField.hidden = false;
                }
            })
            .catch(err => console.log(err)); //catch error

        return false;
    }
}