<?php
$data = json_decode(file_get_contents('php://input'),true);

if(!empty($data)){
    require_once "./databaseConnect.php";

    $conn = newconn();

    $name = $data['name'];
    $pid = $data['pid'];

    //select query
    $sql = "DELETE FROM userPanels where panel_id = '$pid' and username = '$name'";

    $result = mysqli_query($conn, $sql);

    $arr = (Object)array();
    if($result){
        $arr->message = 'successfully removed from '.$name;
    }
    else{
        $arr->message = 'An error occured. Panel not removed';
    }
    echo json_encode($arr, JSON_PRETTY_PRINT).PHP_EOL;
}
else{
    $arr = (Object)array();
    $arr->message = 'An error occured. Panel not removed';
    echo json_encode($arr, JSON_PRETTY_PRINT).PHP_EOL;
}